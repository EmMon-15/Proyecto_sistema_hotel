
package gestion_reservas_hotel;
import java.util.ArrayList;

public class GestionReservas {
    private static ArrayList<Registro> procesosRegistro = new ArrayList<>();
    private static ArrayList<Habitacion> datosHabitacion = new ArrayList<>();
    
    public static void crearHabitacion() {
        Habitacion.aumentarHabitacion();
        Habitacion nuevaHabitacion = new Habitacion();
        guardarHabitacion(nuevaHabitacion);
    }
    
    public static void borrarHabitacion(int habitacion) {
        cancelar(habitacion);
        for (Registro registro: procesosRegistro) {
            if (habitacion == registro.getNumHabitacion()) {
                registro.inhabilitarReserva();
            }
        }
    }
    
    public static void actualizarReservas() {
        for (Registro registro: procesosRegistro) {
            if (registro.getEstadoReserva()) {
                registro.actualizarEstado();
                if (!registro.getEstadoReserva()) {
                    cancelar(registro.getNumHabitacion());
                }
            }
        }
    }
    
    public static void guardarHabitacion(Habitacion nuevaHabitacion) {
        datosHabitacion.add(nuevaHabitacion);
    }
    
    public static void guardarRegistro(Registro nuevoRegistro) {
        procesosRegistro.add(nuevoRegistro);
    }
    
    public static void reservar(Registro nuevoRegistro) {
        int habitacionReservada = nuevoRegistro.getNumHabitacion();
        String cedulaOcupante = nuevoRegistro.getCedulaRegistrado();
        for (Habitacion habitacionRevisada: datosHabitacion) {
            if (habitacionReservada == habitacionRevisada.getNumHabitacion() && habitacionRevisada.getEstadoHabitacion()) {
                habitacionRevisada.reservarEstaHabitacion();
                habitacionRevisada.setCedulaOcupante(cedulaOcupante);
            }
        }
    }
    
    public static void cancelar(int habitacion) {
        if (habitacion > 0) {
            Habitacion aCancelar = getHabitacion(habitacion);
            aCancelar.cancelarEstaHabitacion();
            aCancelar.setCedulaOcupante("0000000000");
        }
    }
    
    public static boolean disponibilidad(int habitacion) {
        if (habitacion <= Habitacion.getNumLlamadas() && Habitacion.getNumLlamadas() > 0) {
            for (Habitacion enSeleccion: datosHabitacion) {
                if (enSeleccion.getEstadoHabitacion() && habitacion == enSeleccion.getNumHabitacion()) {
                    return true;
                }
            }
            System.out.println("La habitacion esta ocupada.");
            return false;
        } else {
            System.out.println("Habitacion seleccionada no es valida.");
        }
        return false;
    }
    
    public static Habitacion getHabitacion(int numHabitacion) {
        Habitacion seleccion;
        if (numHabitacion <= Habitacion.getNumLlamadas() && Habitacion.getNumLlamadas() > 0) {
            for (Habitacion habitacionSeleccionada: datosHabitacion) {
                if (numHabitacion == habitacionSeleccionada.getNumHabitacion()) {
                    seleccion = habitacionSeleccionada;
                    return seleccion;
                }
            }
        } else {
            System.out.println("Habitacion seleccionada no valida");
        }
        return null;
    }
    
    public static Registro getRegistro(int numRegistro) {
        Registro seleccion;
        if (numRegistro <= procesosRegistro.size() && !procesosRegistro.isEmpty()) {
            for (Registro registroSeleccionado: procesosRegistro) {
                if (numRegistro == registroSeleccionado.getNumRegistro()) {
                    seleccion = registroSeleccionado;
                    return seleccion;
                }
            }
        } else {
            System.out.println("Habitacion seleccionada no valida");
        }
        return null;
    }
    //Registros de reservas guardados
    public static void mostrarTodosRegistros() {
        System.out.println("--- LISTA DE TODOS LOS REGISTROS ---");
        for (Registro registro : procesosRegistro) {
            System.out.println("No. Registro: " + registro.getNumRegistro() + 
                               " | Habitación: " + registro.getNumHabitacion() + 
                               " | Cédula Registrada: " + registro.getCedulaRegistrado());
        }
    }

    //Mostrar todas las habitaciones guardadas
    public static void mostrarTodasHabitaciones() {
        System.out.println("--- LISTA DE TODAS LAS HABITACIONES ---");
        for (Habitacion habitacion : datosHabitacion) {
            System.out.println("Número: " + habitacion.getNumHabitacion() + 
                               " | Estado Ocupada/Libre: " + habitacion.getEstadoHabitacion() + 
                               " | Ocupante (Cédula): " + habitacion.getCedulaOcupante());
        }
    }

    //Mostrar habitaciones o registros filtrados para Clientes
    public static void mostrarHabitacionesClientes() {
        System.out.println("--- HABITACIONES ASIGNADAS A CLIENTES ---");
        for (Habitacion habitacion : datosHabitacion) {
            // Si la cédula pertenece a un cliente registrado
            if (GestionUsuarios.compararCedula(habitacion.getCedulaOcupante()) >= 0) {
                System.out.println("Habitación: " + habitacion.getNumHabitacion() + 
                                   " | Cédula Cliente: " + habitacion.getCedulaOcupante());
            }
        }
    }

    //Mostrar habitaciones o registros para Empleados
    public static void mostrarHabitacionesEmpleados() {
        System.out.println("--- HABITACIONES ASIGNADAS A EMPLEADOS ---");
        for (Habitacion habitacion : datosHabitacion) {
            // Lógica para filtrar empleados
            System.out.println("Habitación: " + habitacion.getNumHabitacion() + 
                               " | Cédula Empleado: " + habitacion.getCedulaOcupante());
        }
    }

    //Mostrar registros para empleados de nivel 3 o menor
    public static void mostrarRegistrosEmpleadosNivelMenorIgualTres() {
        System.out.println("--- REGISTROS DE EMPLEADOS (NIVEL <= 3) ---");
        for (Registro registro : procesosRegistro) {
            //validar su nivel <= 3
            System.out.println("Registro ID: " + registro.getNumRegistro() + 
                               " | Cédula: " + registro.getCedulaRegistrado());
        }
    }
}
